import xlrd
import xlwt

filename='test5.log'
filename2='test5.xlsx'

# class student:
#     # height="100"
#     # home=""
#     # dianti="西"
#     # room="00"
#     # course=""
#     # book=""
#     # food=""
#     # sing=""
#     # study=""
#     # pet=""
#     # play=""
#     # major=""
#     # program=""
#     # memory=""
#     # sport=""
#     # wantSay=""
#     info=[""]
#     def __init__(self)


infos={}
workbook=xlwt.Workbook()
worksheet=workbook.add_sheet("data")


def read_excel(file,output):
    log = open(file, "r")  # 打开文件
    for i in range(0,12):
        #读数据
        line = log.readline()

        filename = log.readline()
        filename = filename[filename.find('=')+2+8: len(filename)-1]
        print(filename)

        worksheet.write(i, 1, filename)

        blocksize = log.readline()
        blocksize = log.readline()
        blocksize = blocksize[blocksize.find('=')+2: len(blocksize)-1]
        print(blocksize)

        worksheet.write(i, 2, blocksize)

        way = log.readline()
        way = way[way.find('=')+2: len(way)-1]
        print(way)

        worksheet.write(i, 3, way)

        policy = log.readline()
        policy = policy[policy.find('=')+2: len(policy)-1]
        print(policy)

        worksheet.write(i, 4, policy)

        writepolicy = log.readline()
        iswritealloc = False
        if 'no' in writepolicy:
            iswritealloc = False
        else:
            iswritealloc = True
        print(iswritealloc)

        worksheet.write(i, 5, int(iswritealloc))

        iswriteback = False
        if 'back' in writepolicy:
            iswriteback = True
        else:
            iswriteback = False
        print(iswriteback)

        worksheet.write(i, 6, int(iswriteback))

        h=log.readline()
        hits = h.split(' ')
        hit = int(hits[2])

        worksheet.write(i, 7, hit)

        miss = int(hits[5])
        worksheet.write(i, 8, miss)

        missrate = log.readline().split(' ')[3]
        worksheet.write(i, 9, missrate)
        print(hit)
        print(miss)
        print(missrate)

        line=log.readline()


    workbook.save(output)

        #读完了


    #
    #
    # print(wb.sheet_names())  # 获取所有表格名字
    # sheet1 = wb.sheet_by_index(0)  # 通过索引获取表格
    # sheet2 = wb.sheet_by_name('Sheet1')  # 通过名字获取表格
    # print(sheet1,sheet2)
    # print(sheet1.name, sheet1.nrows, sheet1.ncols)
    # rows = sheet1.row_values(4)  # 获取行内容
    # cols = sheet1.col_values(3)  # 获取列内容
    # print(rows)
    #
    # for j in range(4,50):
    #     info={}
    #     name=sheet1.cell(j,6).value
    #     print(name)
    #     worksheet.write(j, 0, name)
    #     for i in range(14,30):
    #         print(sheet1.cell(j,i).value)
    #         tmp=sheet1.cell(j,i).value
    #         tmp2=tmp[tmp.find('〖')+1:tmp.find('〗')]
    #         number=tmp[0:tmp.find('.')]
    #         info[number]=tmp2
    #         if(tmp2!=''):
    #             worksheet.write(j, int(number), tmp2)
    #     print(info)
    #     infos[name]=info
    #
    #
    # print(cols)
    # print(sheet1.cell(1, 0).value)  # 获取表格里的内容，三种方式
    # print(sheet1.cell_value(1, 0))
    # print(sheet1.row(1)[0].value)
    #
    # workbook.save('2.xlsx')


if __name__=='__main__':
    read_excel(filename,filename2)